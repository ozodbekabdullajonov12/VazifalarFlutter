import "package:flutter/material.dart";

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Center(
        child: Column(
          children: [
            Text(
              "Hello World!",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                backgroundColor: Colors.white,
                fontFamily: 'Times New Roman',
                fontSize: 50,
                color: Colors.deepOrange,
                decoration: TextDecoration.lineThrough,
              ),
            ),
            Text(
              'Hello World!',
              style: TextStyle(
                color: Colors.lightBlue,
                fontSize: 50,
                fontFamily: 'Calibri',
                fontStyle: FontStyle.normal,
                fontWeight: FontWeight.w600,
                decoration: TextDecoration.underline,
              ),
            ),
            Text(
              "Hello World!",
              style: TextStyle(
                color: Colors.amber,
                fontWeight: FontWeight.normal,
                fontSize: 60,
                fontFamily: 'Aptos',
                decoration: TextDecoration.overline,
              ),
            ),
            Text(
              'Hello World!',
              style: TextStyle(
                color: Colors.indigo,
                decoration: TextDecoration.none,
                fontWeight: FontWeight.w800,
                fontFamily: 'Times New Roman',
                fontSize: 46,
              ),
            ),
            Text(
              'Hello World!',
              style: TextStyle(
                color: Colors.greenAccent,
                fontFamily: 'Calibri',
                decoration: TextDecoration.overline,
                fontSize: 50,
                fontWeight: FontWeight.bold,

              ),
            ),
          ],
        ),
      ),
    );
  }
}
